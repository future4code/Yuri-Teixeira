// Exercícios de interpretação de código //

/*

1. 

false
false
true
boolean

2.

a. undefined
b. null
c. 11
d. 3
e. [3, 19, 5, 6, 7, 8, 9, 10, 11, 12, 13]
f. 11

*/

// Exercícios de escrita de código //

/*

1.

let idade = Number(prompt("Qual a sua idade?"))
let idadeMelhorAmigo = Number(prompt("Qual a idade do seu melhor amigo?"))

console.log("Sua idade é maior do que a do seu amigo?", idade > idadeMelhorAmigo)

let diferenca = idade - idadeMelhorAmigo
console.log(diferenca)

2.

const numeroPar = prompt("Insira um número par: ")

console.log(numeroPar % 2)

// Para todos os números pares, vai ser impresso 0
// Para números ímpares, vai ser impresso 1


3.

let listaDeTarefas = []
let tarefa1 = prompt("Digite a tarefa 1: ")
listaDeTarefas.push(tarefa1)

let tarefa2 = prompt("Digite a tarefa 2: ")
listaDeTarefas.push(tarefa2)

let tarefa3 = prompt("Digite a tarefa 3: ")
listaDeTarefas.push(tarefa3)

console.log(listaDeTarefas)

let indice = prompt("Digite o índice da tarefa que você já realizou: ")
listaDeTarefas.splice(indice)

console.log(listaDeTarefas)


4.

let nomeDoUsuario = prompt("Qual o seu nome?")
let emailDoUsuario = prompt("Qual o seu e-mail?")

console.log("O e-mail ", emailDoUsuario, " foi cadastrado com sucesso. Seja bem-vinda(o), ", nomeDoUsuario)

*/